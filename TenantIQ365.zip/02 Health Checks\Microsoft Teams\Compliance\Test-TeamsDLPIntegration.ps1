﻿# TenantIQ Microsoft Teams Health Check #46
# Teams DLP Integration
# Bulk baseline implementation generated from the TenantIQ roadmap.

$HelperPath = Join-Path $PSScriptRoot "..\..\..\01 Framework\Invoke-TenantIQBulkCheck.ps1"
$HelperPath = [System.IO.Path]::GetFullPath($HelperPath)

if (-not (Test-Path $HelperPath)) {
    throw "TenantIQ bulk health-check runtime not found: $HelperPath"
}

. $HelperPath

Invoke-TenantIQBulkCheck `
    -Workload "Microsoft Teams" `
    -CheckName "Teams DLP Integration" `
    -Category "Compliance" `
    -Severity "High"
